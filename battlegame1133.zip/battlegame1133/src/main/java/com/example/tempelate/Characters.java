package com.example.tempelate;

import java.util.ArrayList;

public class Characters {
    private int health;
    private String name;
    private int accuracy;
    private int firepower;
    private int awareness;
    private int leadership;
    private int level=0;
    private int speed;
    private String specialty;
    private Weapons weapon;
    private ArrayList<Item> inventory;
    private int money=1000;
    public Characters(String name, String speciality){
        inventory=new ArrayList<>();
        this.name=name;
        this.specialty=speciality;
        if (speciality.equalsIgnoreCase("sharpshooter")){
            health=50;
            accuracy=95;
            firepower=80;
            awareness=60;
            leadership=20;
            speed=10;
        }
        if (speciality.equalsIgnoreCase("brute")){
            health=200;
            accuracy=45;
            firepower=80;
            awareness=10;
            leadership=40;
            speed=20;
        }
        if (speciality.equalsIgnoreCase("brick")){
            health=600;
            accuracy=10;
            firepower=30;
            awareness=1;
            leadership=1;
            speed=1;

        }
        if (speciality.equalsIgnoreCase("veteran")){
            health=180;
            accuracy=90;
            firepower=50;
            awareness=90;
            leadership=90;
            speed=78;

        }
        if (speciality.equalsIgnoreCase("leader")){
            health=40;
            accuracy=50;
            firepower=50;
            awareness=100;
            leadership=100;
            speed=60;

        }
        if (speciality.equalsIgnoreCase("skitzo john")){
            health=1000;
            accuracy=100;
            firepower=2000;
            awareness=100;
            leadership=100;
            speed=100;

        }
        if (speciality.equalsIgnoreCase("weak")){
            health=30;
            accuracy=30;
            firepower=30;
            awareness=30;
            leadership=30;
            speed=10;

        }
        if (speciality.equalsIgnoreCase("mid")){
            health=60;
            accuracy=60;
            firepower=70;
            awareness=60;
            leadership=60;
            speed=30;

        }
        if (speciality.equalsIgnoreCase("strong")){
            health=90;
            accuracy=90;
            firepower=90;
            awareness=90;
            leadership=90;
            speed=70;

        }
        if (speciality.equalsIgnoreCase("boss")){
            health=100;
            accuracy=100;
            firepower=100;
            awareness=100;
            leadership=100;
            speed=100;

        }


    }
    public int getinvlength(){
        return inventory.size();
    }
    public Item getinvitem(int index){
        return inventory.get(index);
    }

    public void addpotion(int hp){
        inventory.add(new Item(hp,"potion"));
    }
    public void usepotion(){
        for (int i=0;i<inventory.size();i++){
            if (inventory.get(i).getname().equals("potion")){
                health+=inventory.get(i).useitem();
                inventory.remove(i);
                break;
            }
        }
    }
    public void setnewweapon(Weapons weapon1){
        weapon=weapon1;
    }

    public int gethealth(){
        return health;
    }
    public boolean areyoualive(){
        if (health>0){
            return true;
        }else{
            return false;
        }
    }
    public void specificstate(String name,int health,int accuracy,int firepower,int awareness,int leadership, int speed){
        this.health=health;
        this.name=name;
        this.accuracy=accuracy;
        this.firepower=firepower;
        this.awareness=awareness;
        this.leadership=leadership;
        this.speed=speed;
    }
    public String getname(){
        return name;
    }
    public int getaccuracy(){
        return accuracy;
    }
    public void addhealth(int amount){
        health+=amount;
    }
    public int getmoney(){
        return money;
    }
    public void changemoney(int amount){
        money+=amount;
    }
    public int getfirepower(){
        return firepower;
    }
    public int getawareness(){
        return awareness;
    }
    public int getleadership(){
        return leadership;
    }
    public int getlevel(){
        return level;
    }
    public void levelup(){
        level+=1;
        awareness+=1;
        accuracy+=1;
        firepower+=1;
        leadership+=1;
    }
    public Weapons getweapon(){
        return weapon;
    }
    public String getspecialty(){
        return specialty;
    }
    public int getspeed(){
        return speed;
    }
    public void makeweapon(String name,String type,int range,int power,int skill){
        weapon=new Weapons(name,type,range,power,skill);
    }
    public void damage(int num){
        health-=num;
    }




}
