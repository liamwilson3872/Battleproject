package com.example.tempelate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

public class HelloController {
    public Button btnclick;
    public Label lbldisplay;
    public TextField txtinput;
    public TextArea battleLog;
    public Button attackButton;
    public Button magicButton;
    public Button defendButton;
    public Button itemButton;
    public Button runButton;
    public Label turnLabel;
    public Button negotiationbutton;
    public TextField txtCommand;
    public Button btnCommand;
    public ProgressBar enemyHPBar;
    public Label enemyName;
    public ListView inventoryList;
    public Label playerLevel;
    public Label hptxt;
    public Label playerName;
    public Label playerhp;
    public ListView enemylist;
    public Label speedtxt;
    public Label enemyspeedtxt;
    public ListView shoplist;
    public Label shoptxt;
    public Button openshopbtn;
    public Label moneytxt;
    public ListView enemyinvlist;
    public Label wpndmgtxt;
    public Label strengthtxt;
    private int count = 0;
    private Playgame game;
    private String speciality;
    private String name;
    private int enemyselection;

    public void initialize() {
        battleLog.appendText("hello, please choose what class you are. sharpshooter, brute, leader, veteran, or brick.");
        game = new Playgame();
        shoptxt.setVisible(false);
        shoplist.setVisible(false);
        shoplist.getItems().add("random new weapon-$100");
        shoplist.getItems().add("health potion-$75");
        shoplist.getItems().add("1 Level Up-$50");

    }

    public void btnclick(ActionEvent actionEvent) {
        System.out.println("click");
    }

    public void handleDefend(ActionEvent actionEvent) {
        battleLog.appendText("You fortified yourself and healed 75 hp");
        game.getteammate(0).addhealth(75);
        updateTurnLabel();
        seteverything();
    }

    public void handleUseItem(ActionEvent actionEvent) {
        game.getteammate(0).usepotion();
        playerhp.setText(String.valueOf(game.getteammate(0).gethealth()));
        seteverything();
    }

    public void handleRun(ActionEvent actionEvent) {
    }

    public void handleCommand(ActionEvent actionEvent) {
        if (count == 0) {
            speciality = txtCommand.getText();
            count += 1;
            battleLog.clear();
            battleLog.appendText("now type your name\n");

        } else if (count == 1) {
            name = txtCommand.getText();
            count += 1;
            game.makeplayer(name, speciality);
            System.out.println(game.getteammate(0).getspecialty());
            System.out.println(game.getteammate(0).getname());
            battleLog.appendText("Your name is " + game.getteammate(0).getname() + " and your class is " + game.getteammate(0).getspecialty() + "\n");

        } else if (count > 1) {
            battleLog.appendText("you wake up in a large field...you see your crashed f-15 jet next to you covered in dents and damage...\n");
            battleLog.appendText("You see your trusty weapon on the ground next to you. you pick it up\n");
            game.getteammate(0).makeweapon("revolver", "pistol", 50, 30, 10);
            inventoryList.getItems().add("revolver");
            battleLog.appendText("You now own a revolver here are its stats. name: " + game.getteammate(0).getweapon().getname() + " | range: 50 | power: 30 | skill: 10\n");
            battleLog.appendText("a tall figure appears in front of you. it looks like some sort of blob. it begins rushing towards you. select what to do\n");
            game.battlestart();
            game.newenemy();
            game.getteammate(0).addpotion(100);
            game.getteammate(0).addpotion(100);
            game.getteammate(0).addpotion(100);

            System.out.println("yay");
            seteverything();
            updateTurnLabel();


        }
        if (txtCommand.getText().equals("add battles")){
            game.addbattle(10);
        }
    }

    public void handleAttack(ActionEvent actionEvent) {
        game.getteammate(0).changemoney(50);
        game.getteammate(0).levelup();
        if (game.getenemy(enemyselection).gethealth() > game.calcdamage()) {
            game.attack(game.getenemy(enemyselection).getname());
            setenemystats(enemyselection);
            seteverything();
        } else {
            game.getenemyteam().killteammember(enemyselection);
            enemylist.getItems().remove(enemyselection);
            enemyName.setText("Dead");
            hptxt.setText("0");
        }

    }

    public void Negotiate(ActionEvent actionEvent) {
        double intimidation=game.getteammate(0).getleadership();
        int weaponbonus=game.getteammate(0).getweapon().getpower();
        int enemyleadership=game.getenemy(0).getleadership();
        int enemytotalhp=0;
        for (int i=0;i<game.getenemyteam().getteamlength();i++){
            enemytotalhp+=game.getenemy(0).gethealth();
        }
        int hptotalbonus=game.getteammate(0).gethealth()-enemytotalhp;
        intimidation+=(weaponbonus*0.5);
        intimidation+=(hptotalbonus*0.3);
        intimidation-=(enemyleadership*0.3);
        int rnum=(int)(Math.random()*100);
        System.out.println(intimidation);
        System.out.println(rnum);
        if (intimidation>rnum){
            int moneyrnum=(int)(Math.random()*200);
            battleLog.appendText("They decided to surrender. they lay down there guns and money and surrender. some might continue to fight. you got $"+moneyrnum);
            game.getteammate(0).changemoney(moneyrnum);
            game.enemysurrender();
            seteverything();
            updateTurnLabel();
        }

    }

    public void seteverything() {
        speedtxt.setText(String.valueOf(game.getteammate(0).getspeed()));
        strengthtxt.setText(String.valueOf(game.getteammate(0).getfirepower()));
        wpndmgtxt.setText(String.valueOf(game.getteammate(0).getweapon().getpower()));
        enemylist.getItems().clear();
        for (int i = 0; i < game.getenemyteam().getteamlength(); i++) {
            if (game.getenemy(i).areyoualive()) { // NEW: skip dead enemies
                enemylist.getItems().add(game.getenemy(i).getname());
            }
        }
        if (enemyselection < game.getenemyteam().getteamlength() && game.getenemy(enemyselection).areyoualive()) {
            enemyName.setText(game.getenemy(enemyselection).getname());
            hptxt.setText(String.valueOf(game.getenemy(enemyselection).gethealth()));
        }
        playerName.setText(game.getteammate(0).getname());
        playerhp.setText(String.valueOf(game.getteammate(0).gethealth()));
        moneytxt.setText(String.valueOf(game.getteammate(0).getmoney()));
        inventoryList.getItems().clear();
        inventoryList.getItems().add(game.getteammate(0).getweapon().getname());
        for (int i=0;i<game.getteammate(0).getinvlength();i++){
            inventoryList.getItems().add(game.getteammate(0).getinvitem(i).getname());
        }

    }

    public void setenemystats(int index) {
        if (game.getenemy(index).areyoualive()) {
            enemyName.setText(game.getenemy(index).getname());
            hptxt.setText(String.valueOf(game.getenemy(index).gethealth()));
        } else {
            enemyName.setText("Dead ");
            hptxt.setText("0");
        }
    }

    public void setplayerstats(int index) {
        if (game.getteammate(index).areyoualive()) {
            playerName.setText(game.getteammate(index).getname());
            playerhp.setText(String.valueOf(game.getteammate(index).gethealth()));
            speedtxt.setText(String.valueOf(game.getteammate(0).getspeed()));
        } else {
            playerName.setText("Dead ");
            playerhp.setText("0");
        }
    }

    public void handleenemynameclick(MouseEvent mouseEvent) {
        enemyselection = enemylist.getSelectionModel().getSelectedIndex();
        System.out.println(enemyselection);
        System.out.println(game.getenemy(enemyselection).getname());
        hptxt.setText(String.valueOf(game.getenemy(enemyselection).gethealth()));
        enemyName.setText(game.getenemy(enemyselection).getname());
        enemyspeedtxt.setText(String.valueOf(game.getenemy(enemyselection).getspeed()));
        enemyinvlist.getItems().clear();
        enemyinvlist.getItems().add("name= "+game.getenemy(enemyselection).getweapon().getname());
        enemyinvlist.getItems().add("Power= "+game.getenemy(enemyselection).getweapon().getpower());
        enemyinvlist.getItems().add("range= "+game.getenemy(enemyselection).getweapon().getrange());
        enemyinvlist.getItems().add("type= "+game.getenemy(enemyselection).getweapon().getType());
    }
    private int playerinvselection;
    public void handleplayerinvclicked(){
        playerinvselection=inventoryList.getSelectionModel().getSelectedIndex();


    }


    private void updateTurnLabel() {
        seteverything();
        Characters current = game.getcurrentturn();
        if (current != null) {
            turnLabel.setText("it's " + current.getname() + "'s turn (" + current.getspeed() + " speed)");
        } else {
            turnLabel.setText("The battle has ended");
            if (game.getnumofbattles()==0){
                battleLog.appendText("You did it :). you can buy things from the shop. you also now gain a level each time you attack. 1 level doesnt improve you that much but over time they add up."+"\n");
            }
            game.endbattle();

        }

    }
    public void shop(){
        battleLog.clear();
        battleLog.appendText("Welcome to the shop.you can buy a new weapon, buy potions, or level up here. just click to buy."+"\n");
        shoplist.setVisible(true);
        shoptxt.setVisible(true);

    }
    private int shopitemselection;
    public void handleshopnameclick(MouseEvent mouseEvent) {
        shopitemselection = shoplist.getSelectionModel().getSelectedIndex();
        if (shopitemselection==0){
            if (game.getteammate(0).getmoney()>100){
                battleLog.appendText("You purchased this brand new weapon. you now have "+game.getteammate(0).getmoney()+"\n");

                game.getteammate(0).changemoney(-100);
                game.getteammate(0).setnewweapon(game.randomweapon());
                seteverything();
            }else{
                battleLog.appendText("Not enough money"+"\n");
            }

        }
        if (shopitemselection==1){
            if (game.getteammate(0).getmoney()>75) {
                battleLog.appendText("You just got a potion worth 100 health. use it by clicking use potion"+"\n");
                game.getteammate(0).addpotion(100);
                game.getteammate(0).changemoney(-75);
                seteverything();
            }else{
                battleLog.appendText("not enough money"+"\n");
            }

        }
        if (shopitemselection==2){
            if (game.getteammate(0).getmoney()>50) {
                battleLog.appendText("you just bought 1 level. all your stats increase" + game.getteammate(0).getmoney()+"\n");
                game.getteammate(0).levelup();
                game.getteammate(0).changemoney(-50);
                seteverything();
            }else{
                battleLog.appendText("Not enough money"+"\n");
            }

        }
    }

    public void opencloseshop(MouseEvent mouseEvent) {
        if (shoplist.isVisible()==true){
            shoplist.setVisible(false);
            shoptxt.setVisible(false);
        }
        if (shoplist.isVisible()==false){
            shoplist.setVisible(true);
            shoptxt.setVisible(true);
        }
    }

    public void handleAddUser(ActionEvent actionEvent) {
    }
}
