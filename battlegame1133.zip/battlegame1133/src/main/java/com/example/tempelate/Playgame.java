package com.example.tempelate;

import java.util.ArrayList;
import java.util.Comparator;

public class Playgame {
    private Characters characters;
    private Team enemys;
    private Team team;
    private ArrayList<Characters> turnorder = new ArrayList<>();
    //jf==
    private ArrayList<Weapons> possibleweapons=new ArrayList<>();
    private int numofbattles=0;
    private ArrayList<Characters> randchar=new ArrayList<>();
    private ArrayList<Weapons> possibleenemyweapons=new ArrayList<>();


    public Playgame() {
        team = new Team();
        enemys = new Team();
        randchar.add(new Characters("Scoundrel","brute"));
        randchar.add(new Characters("Glob","sharpshooter"));
        randchar.add(new Characters("Enforcer","brick"));
        randchar.add(new Characters("Wraith","sharpshooter"));
        randchar.add(new Characters("Banshee","sharpshooter"));
        randchar.add(new Characters("Marauder","veteran"));
        randchar.add(new Characters("Thorn","strong"));
        randchar.add(new Characters("Grimjaw","strong"));
        randchar.add(new Characters("Specter","Strong"));
        randchar.add(new Characters("Blightfang","Strong"));
        randchar.add(new Characters("Alien","weak"));
        randchar.add(new Characters("Alien Commander","mid"));
        randchar.add(new Characters("Alien General","Strong"));
        randchar.add(new Characters("Alien Queen","Boss"));
        randchar.get(randchar.size()-1).specificstate("Alien Queen",300,50,80,70,0,50);
        randchar.add(new Characters("Alien God","brute"));
        randchar.get(randchar.size()-1).specificstate("Alien God",600,40,160,100,0,20);
        randchar.add(new Characters("Alien Tax Collector","brute"));
        randchar.get(randchar.size()-1).specificstate("Alien Tax Collector",250,70,190,100,0,100);
        possibleweapons.add(new Weapons("axe","primitive",10,40,10));
        possibleweapons.add(new Weapons("stick","primitive",5,5,5));
        possibleweapons.add(new Weapons("rusty bat", "primitive", 10, 30, 0));
        possibleweapons.add(new Weapons("filed toothbrush", "primitive", 5, 30, 0));
        possibleweapons.add(new Weapons("", "primitive", 5, 30, 0));
        possibleweapons.add(new Weapons("nail gun","advanced",50,30,20));
        possibleweapons.add(new Weapons("sledge hammer","advanced",20,90,90));
        possibleweapons.add(new Weapons("acid breath", "natural", 30, 20, 0));
        possibleweapons.add(new Weapons("laser implant", "alien", 90, 70, 0));
        possibleweapons.add(new Weapons("laser sword", "alien", 20, 80, 40));
        possibleweapons.add(new Weapons("glove of doom", "alien", 10, 200, 0));
        possibleweapons.add(new Weapons("the alien from alien but as a weapon", "alien", 20, 100, 0));
        possibleweapons.add(new Weapons("pistol", "modern", 40, 50, 30));
        possibleweapons.add(new Weapons("revolver", "modern", 40, 60, 50));
        possibleweapons.add(new Weapons("bazooka", "modern", 20, 90, 30));
        possibleweapons.add(new Weapons("chat gpt", "divine", 100, 600, 10));
        possibleweapons.add(new Weapons("BILL", "divine", 9999999, 99999999, 0));
        for (int i=0;i<randchar.size();i++){
            Weapons weapon=possibleweapons.get((int)(Math.random()*possibleweapons.size()-1));
            randchar.get(i).makeweapon(weapon.getname(),weapon.getType(),weapon.getrange(),weapon.getpower(),20);
            randchar.get(i).addpotion(100);
        }












    }

    public Weapons randomweapon(){
        int rnum=(int)(Math.random()*possibleweapons.size()-1);
        Weapons newweapon=possibleweapons.get(rnum);
        return newweapon;
    }
    public Team getteam() {
        return team;
    }

    public Team getenemyteam() {
        return enemys;
    }

    public void makeplayer(String name, String speciality) {
        characters = new Characters(name, speciality);
        team.addteam(characters);
    }

    public void makeenemy(String name, String speciality) {
        characters = new Characters(name, speciality);
        enemys.addteam(characters);
    }

    public Characters getteammate(int index) {
        return team.getcharacter(index);
    }

    public Characters getenemy(int index) {
        return enemys.getcharacter(index);
    }

    public void maketurnorder() {
        turnorder.clear();
        for (int i = 0; i < team.getteamlength(); i++) {
            turnorder.add(team.getcharacter(i));
        }
        for (int i = 0; i < enemys.getteamlength(); i++) {
            turnorder.add(enemys.getcharacter(i));
        }

        turnorder.sort(Comparator.comparingInt(Characters::getspeed).reversed());
    }

    public Characters getcurrentturn() {
        if (turnorder.size()!=0){
            return turnorder.get(0);

        }else{
            return null;
        }
    }

    public boolean areyouaenemy(Characters chara) {
        for (int i = 0; i < team.getteamlength(); i++) {
            if (team.getcharacter(i).getname().equals(chara.getname())) {
                return false;
            }
        }
        return true;
    }


    public void nextturn() {
        if (turnorder.size()!=0){
            Characters current = turnorder.remove(0);
            if (current.areyoualive()) {
                turnorder.add(current);
            }
            while (turnorder.size() > 0 && !turnorder.get(0).areyoualive()) {
                turnorder.remove(0);
            }


            if (turnorder.size()==0) {
                System.out.println("All characters are dead. Battle over.");
            }
        }else {


        }
        if (areyouaenemy(getcurrentturn())==true){
            System.out.println("started");
            int rnum= (int) (Math.random()*team.getteamlength()-1);
            attack(team.getcharacter(rnum).getname());
        }
    }

    public int calcdamage() {
        Characters attacker = turnorder.get(0);
        return (attacker.getfirepower()/2) + (attacker.getweapon().getpower()/2);
    }

    public int findindexoftarget(String whotoattack) {
        for (int i = 0; i < enemys.getteamlength(); i++) {
            if (enemys.getcharacter(i).getname().equals(whotoattack)) {
                return i;
            }
        }
        for (int i = 0; i < team.getteamlength(); i++) {
            if (team.getcharacter(i).getname().equals(whotoattack)) {
                return i;
            }
        }
        return -1;
    }

    public void attack(String whotoattack) {
        if (turnorder.size()==0) {
            System.out.println("No one left to attack.");
            return;
        }


        int index = findindexoftarget(whotoattack);

        if (index == -1) {
            System.out.println("Target not found: " + whotoattack);
            nextturn();
            return;
        }

        Characters attacker = turnorder.get(0);
        String side="";
        for (int i=0;i<enemys.getteamlength();i++){
            if (whotoattack.equals(enemys.getcharacter(i).getname())){
                side="enemy";

            }
        }
        for (int i=0;i<team.getteamlength();i++){
            if (whotoattack.equals(team.getcharacter(i).getname())){
                side="teammate";
                int rnum=(int)(Math.random()*10);

                if (rnum==1){
                    System.out.println(turnorder.get(0).getname()+" tried to use a potion");
                    if (turnorder.get(i).getinvlength()==0){
                        System.out.println("But he has no potions");
                    }

                        for (int k=0;k<turnorder.get(0).getinvlength();i++){
                        if (turnorder.get(0).getinvitem(k).getname().equals("potion")) {
                            turnorder.get(0).usepotion();
                            System.out.println(turnorder.get(0).getname() + " successfully used a potion");
                            break;
                        }else{
                            System.out.println(turnorder.get(0).getname()+" was out of potions");
                        }

                    }
                }
            }
        }
        int damage = calcdamage();
        Characters target;
        if (side=="enemy"){
            target=enemys.getcharacter(index);
        }else if (side=="teammate"){
            target=team.getcharacter(index);
        }else{
            target=null;
        }
        target.damage(damage);

        if (!target.areyoualive()) {
            System.out.println(target.getname() + " has died!");
        } else {
            System.out.println(attacker.getname() + " dealt " + damage + " to " + target.getname());
            System.out.println(target.getname() + " has " + target.gethealth() + " HP left.");
        }
        int count=0;
        for (int i=0; i<team.getteamlength();i++){
            if (team.getcharacter(i).areyoualive()==true){
                count+=1;
            }
        }
        if (count>0){
            nextturn();
        }else{
            System.out.println("battles over");
           endbattle();
        }
    }

    public void battlestart() {
        makeenemy("glob", "brute");
        makeenemy("scoundrel", "brute");
        getenemy(0).makeweapon("acid breath", "natural", 30, 20, 0);
        getenemy(1).makeweapon("rusty pipe", "primitive", 20, 20, 0);
        maketurnorder();
        if (areyouaenemy(getcurrentturn())==true){
            System.out.println("started");
            int rnum= (int) (Math.random()*team.getteamlength());
            attack(team.getcharacter(0).getname());
        }
    }
    public void addbattle(int num){
        numofbattles+=num;
    }

    public void newenemy(){
        //MAKE IT NOT ALWAYS DO THE LAST ONE
        int rnum=(int)(Math.random()*randchar.size()-1);
        rnum=rnum/2;
        int scaling=0;
        if (numofbattles>50){
            scaling+=12;
        }else if (numofbattles>40){
            scaling+=8;
        }else if (numofbattles>30){
            scaling+=6;
        }else if (numofbattles>20){
            scaling+=3;
        }else if (numofbattles>10){
            scaling+=1;
        }else{
            scaling+=0;
        }
        rnum+=scaling;
        int subjagater= (int) (Math.random() * 4);
        rnum=rnum+(numofbattles);
        if (rnum>randchar.size()-1){
            rnum=randchar.size()-1;
            rnum=rnum-subjagater;
        }
        enemys.addteam(randchar.get(rnum));
        maketurnorder();
    }

    public void endbattle(){
        turnorder.clear();
        numofbattles+=1;
    }
    public int getnumofbattles(){
        return numofbattles;
    }

    public void enemysurrender(){
        for (int i=0;i<enemys.getteamlength();i++){
            int rnum=(int)(Math.random()*10);
            if (rnum==1){
                System.out.println("doesnt surrender");
            }else {
                enemys.killteammember(i);
            }
        }
    }

}
