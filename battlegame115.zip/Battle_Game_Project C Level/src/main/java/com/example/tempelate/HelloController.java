package com.example.tempelate;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;

public class HelloController {

    public Button btnclick;
    public Label lbldisplay;
    public TextField txtinput;
    public TextArea battleLog;
    public Button attackButton;
    public Button magicButton;
    public Button defendButton;
    public Button itemButton;
    public Button runButton;
    public Label turnLabel;
    public Button negotiationbutton;
    public TextField txtCommand;
    public Button btnCommand;
    public ProgressBar enemyHPBar;
    public Label enemyName;
    public ListView inventoryList;
    public Label playerLevel;
    public Label hptxt;
    public Label playerName;
    public Label playerhp;
    public ListView enemylist;
    public Label speedtxt;
    public Label enemyspeedtxt;
    public ListView shoplist;
    public Label shoptxt;
    public Button openshopbtn;
    private int count = 0;
    private Playgame game;
    private String speciality;
    private String name;
    private int enemyselection;

    public void initialize() {
        battleLog.appendText("hello, please choose what class you are. sharpshooter, brute, leader, veteran, or brick.");
        game = new Playgame();
        shoptxt.setVisible(false);
        shoplist.setVisible(false);
        shoplist.getItems().add("random new weapon-$100");
        shoplist.getItems().add("heal 100 health-$75");
        shoplist.getItems().add("1 Level Up-$50");
    }

    public void btnclick(ActionEvent actionEvent) {
        System.out.println("click");
    }

    public void handleDefend(ActionEvent actionEvent) {
    }

    public void handleUseItem(ActionEvent actionEvent) {
    }

    public void handleRun(ActionEvent actionEvent) {
    }

    public void handleCommand(ActionEvent actionEvent) {
        if (count == 0) {
            speciality = txtCommand.getText();
            count += 1;
            battleLog.clear();
            battleLog.appendText("now type your name\n");

        } else if (count == 1) {
            name = txtCommand.getText();
            count += 1;
            game.makeplayer(name, speciality);
            System.out.println(game.getteammate(0).getspecialty());
            System.out.println(game.getteammate(0).getname());
            battleLog.appendText("Your name is " + game.getteammate(0).getname() + " and your class is " + game.getteammate(0).getspecialty() + "\n");

        } else if (count > 1) {
            battleLog.appendText("you wake up in a large field...you see your crashed f-15 jet next to you covered in dents and damage...\n");
            battleLog.appendText("You see your trusty weapon on the ground next to you. you pick it up\n");
            game.getteammate(0).makeweapon("revolver", "pistol", 50, 30, 10);
            inventoryList.getItems().add("revolver");
            battleLog.appendText("You now own a revolver here are its stats. name: " + game.getteammate(0).getweapon().getname() + " | range: 50 | power: 30 | skill: 10\n");
            battleLog.appendText("a tall figure appears in front of you. it looks like some sort of blob. it begins rushing towards you. select what to do\n");
            game.makeenemy("glob", "brute");
            game.makeenemy("scoundrel", "brute");
            game.getenemy(0).makeweapon("acid breath", "natural", 30, 20, 0);
            game.getenemy(1).makeweapon("rusty pipe", "primitive", 20, 20, 0);

            setenemystats(game.findindexoftarget("glob"));
            seteverything();
            game.battlestart();
            updateTurnLabel();

        }
    }

    public void handleAttack(ActionEvent actionEvent) {
        if (game.getenemy(enemyselection).gethealth() > game.calcdamage()) {
            game.attack(game.getenemy(enemyselection).getname());
            setenemystats(enemyselection);
            seteverything();
        } else {
            game.getenemyteam().killteammember(enemyselection);
            enemylist.getItems().remove(enemyselection);
            enemyName.setText("Dead");
            hptxt.setText("0");
        }

        updateTurnLabel();
    }

    public void Negotiate(ActionEvent actionEvent) {
    }

    public void seteverything() {
        enemylist.getItems().clear();
        for (int i = 0; i < game.getenemyteam().getteamlength(); i++) {
            if (game.getenemy(i).areyoualive()) { // NEW: skip dead enemies
                enemylist.getItems().add(game.getenemy(i).getname());
            }
        }
        if (enemyselection < game.getenemyteam().getteamlength() && game.getenemy(enemyselection).areyoualive()) {
            enemyName.setText(game.getenemy(enemyselection).getname());
            hptxt.setText(String.valueOf(game.getenemy(enemyselection).gethealth()));
        }
        playerName.setText(game.getteammate(0).getname());
        playerhp.setText(String.valueOf(game.getteammate(0).gethealth()));
    }

    public void setenemystats(int index) {
        if (game.getenemy(index).areyoualive()) {
            enemyName.setText(game.getenemy(index).getname());
            hptxt.setText(String.valueOf(game.getenemy(index).gethealth()));
        } else {
            enemyName.setText("Dead ");
            hptxt.setText("0");
        }
    }

    public void setplayerstats(int index) {
        if (game.getteammate(index).areyoualive()) {
            playerName.setText(game.getteammate(index).getname());
            playerhp.setText(String.valueOf(game.getteammate(index).gethealth()));
            speedtxt.setText(String.valueOf(game.getteammate(0).getspeed()));
        } else {
            playerName.setText("Dead ");
            playerhp.setText("0");
        }
    }

    public void handleenemynameclick(MouseEvent mouseEvent) {
        enemyselection = enemylist.getSelectionModel().getSelectedIndex();
        System.out.println(enemyselection);
        System.out.println(game.getenemy(enemyselection).getname());
        hptxt.setText(String.valueOf(game.getenemy(enemyselection).gethealth()));
        enemyName.setText(game.getenemy(enemyselection).getname());
        enemyspeedtxt.setText(String.valueOf(game.getenemy(enemyselection).getspeed()));
    }

    private void updateTurnLabel() {
        seteverything();
        Characters current = game.getcurrentturn();
        if (current != null) {
            turnLabel.setText("it's " + current.getname() + "'s turn (" + current.getspeed() + " speed)");
        } else {
            turnLabel.setText("The battle has ended");
            game.endbattle();

        }

    }
    public void shop(){
        battleLog.clear();
        battleLog.appendText("Welcome to the shop.you can buy a new weapon, buy health, or level up here. just click to buy.");
        shoplist.setVisible(true);
        shoptxt.setVisible(true);

    }
    private int shopitemselection;
    public void handleshopnameclick(MouseEvent mouseEvent) {
        shopitemselection = shoplist.getSelectionModel().getSelectedIndex();
        if (shopitemselection==0){
            battleLog.appendText("You purchased this brand new weapon. you now have "+game.getteammate(0).getmoney());
            //MAKE RANDOM WEAPON TOMORROW and make it check if you have enough money______________________________________________________________________

            game.getteammate(0).changemoney(-100);
            seteverything();
        }
        if (shopitemselection==1){
            battleLog.appendText("You just restored 100 health points"+game.getteammate(0).getmoney());
            game.getteammate(0).addhealth(100);
            game.getteammate(0).changemoney(-75);
            seteverything();

        }
        if (shopitemselection==2){
            battleLog.appendText("you just bought 1 level. all your stats increase"+game.getteammate(0).getmoney());
            game.getteammate(0).levelup();
            game.getteammate(0).changemoney(-50);
            seteverything();

        }
    }

    public void opencloseshop(MouseEvent mouseEvent) {
        if (shoplist.isVisible()==true){
            shoplist.setVisible(false);
            shoptxt.setVisible(false);
        }
        if (shoplist.isVisible()==false){
            shoplist.setVisible(true);
            shoptxt.setVisible(true);
        }
    }
}
