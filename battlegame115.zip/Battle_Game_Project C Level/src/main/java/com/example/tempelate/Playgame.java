package com.example.tempelate;

import java.util.ArrayList;
import java.util.Comparator;

public class Playgame {
    private Characters characters;
    private Team enemys;
    private Team team;
    private ArrayList<Characters> turnorder = new ArrayList<>();

    public Playgame() {
        team = new Team();
        enemys = new Team();
    }

    public Team getteam() {
        return team;
    }

    public Team getenemyteam() {
        return enemys;
    }

    public void makeplayer(String name, String speciality) {
        characters = new Characters(name, speciality);
        team.addteam(characters);
    }

    public void makeenemy(String name, String speciality) {
        characters = new Characters(name, speciality);
        enemys.addteam(characters);
    }

    public Characters getteammate(int index) {
        return team.getcharacter(index);
    }

    public Characters getenemy(int index) {
        return enemys.getcharacter(index);
    }

    public void maketurnorder() {
        turnorder.clear();
        for (int i = 0; i < team.getteamlength(); i++) {
            turnorder.add(team.getcharacter(i));
        }
        for (int i = 0; i < enemys.getteamlength(); i++) {
            turnorder.add(enemys.getcharacter(i));
        }

        turnorder.sort(Comparator.comparingInt(Characters::getspeed).reversed());
    }

    public Characters getcurrentturn() {
        if (turnorder.size()!=0){
            return turnorder.get(0);

        }else{
            return null;
        }
    }

    public boolean areyouaenemy(Characters chara) {
        for (int i = 0; i < team.getteamlength(); i++) {
            if (team.getcharacter(i).getname().equals(chara.getname())) {
                return false;
            }
        }
        return true;
    }


    public void nextturn() {
        if (turnorder.size()!=0){
            Characters current = turnorder.remove(0);
            if (current.areyoualive()) {
                turnorder.add(current);
            }

            while (turnorder.size() > 0 && !turnorder.get(0).areyoualive()) {
                turnorder.remove(0);
            }


            if (turnorder.size()==0) {
                System.out.println("All characters are dead. Battle over.");
            }
        }else {


        }
        if (areyouaenemy(getcurrentturn())==true){
            System.out.println("started");
            int rnum= (int) (Math.random()*team.getteamlength()-1);
            attack(team.getcharacter(rnum).getname());
        }
    }

    public int calcdamage() {
        Characters attacker = turnorder.get(0);
        return (attacker.getfirepower()/2) + (attacker.getweapon().getpower()/2);
    }

    public int findindexoftarget(String whotoattack) {
        for (int i = 0; i < enemys.getteamlength(); i++) {
            if (enemys.getcharacter(i).getname().equals(whotoattack)) {
                return i;
            }
        }
        for (int i = 0; i < team.getteamlength(); i++) {
            if (team.getcharacter(i).getname().equals(whotoattack)) {
                return i;
            }
        }
        return -1;
    }

    public void attack(String whotoattack) {
        if (turnorder.size()==0) {
            System.out.println("No one left to attack.");
            return;
        }

        int damage = calcdamage();
        int index = findindexoftarget(whotoattack);

        if (index == -1) {
            System.out.println("Target not found: " + whotoattack);
            nextturn();
            return;
        }

        Characters attacker = turnorder.get(0);
        String side="";
        for (int i=0;i<enemys.getteamlength();i++){
            if (whotoattack.equals(enemys.getcharacter(i).getname())){
                side="enemy";
            }
        }
        for (int i=0;i<team.getteamlength();i++){
            if (whotoattack.equals(team.getcharacter(i).getname())){
                side="teammate";
            }
        }
        Characters target;
        if (side=="enemy"){
            target=enemys.getcharacter(index);
        }else if (side=="teammate"){
            target=team.getcharacter(index);
        }else{
            target=null;
        }
        target.damage(damage);

        if (!target.areyoualive()) {
            System.out.println(target.getname() + " has died!");
        } else {
            System.out.println(attacker.getname() + " dealt " + damage + " to " + target.getname());
            System.out.println(target.getname() + " has " + target.gethealth() + " HP left.");
        }
        int count=0;
        for (int i=0; i<team.getteamlength();i++){
            if (team.getcharacter(i).areyoualive()==true){
                count+=1;
            }
        }
        if (count>0){
            nextturn();
        }else{
            System.out.println("battles over");
           endbattle();
        }
    }

    public void battlestart() {
        maketurnorder();
        if (areyouaenemy(getcurrentturn())==true){
            System.out.println("started");
            int rnum= (int) (Math.random()*team.getteamlength());
            attack(team.getcharacter(0).getname());
        }
    }
    public void endbattle(){
        turnorder.clear();
    }
}
