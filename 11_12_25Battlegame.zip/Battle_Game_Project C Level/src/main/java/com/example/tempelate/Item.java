package com.example.tempelate;

public class Item {
    private int hpheal;
    private String name;
    public Item(int hphealed,String name){
        hpheal=hphealed;
        this.name=name;

    }
    public int useitem(){
        return hpheal;

    }
    public String getname(){
        return name;
    }


}
